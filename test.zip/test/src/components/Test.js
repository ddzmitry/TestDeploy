import React,{Component}from 'react';

class Test extends Component {
  constructor(props) {
    
    super(props);


   this.state = {
    // ...props,
    city:'',
    weather:'Rainy',
    name : 'Melanie'
   }
  }


  render() {
      console.log('State')
      console.log(this.state)


    return (

    

        <div>
            <h1> This is a {this.state.city ? this.state.city: 'Charlotte'  }</h1>
        <pre>
        <h1>🙋</h1>
            Hello my name is {this.state.name}
        </pre>

        
        <input 
        onChange = { (e)=>{ this.setState({name:e.target.value})  }}
        
        type="text"/>


        </div>

    )
  }


  componentDidMount() {
    // debugger;
    console.log(this.state)
    // debugger;
    console.log('CDM')
    // this is a spot where all API calls are usually nade
    this.setState({
        city:'Washington DC'
    })
  }
  
  componentWillMount () {
      
  }

  componentWillReceiveProps (a,b){
    console.log('componentWillReceiveProps')
    console.log(a,b)
  }

  componentWillUnmount () {
    console.log('componentWillUnmount')
   
  }

  componentWillUpdate (props,newState) {
    console.log('componentWillUpdate')
    console.log(props)
    // props.name = 'Dzmitry'
    // this.props.name = 'Dzmitry'
    console.log(newState)  
    // newState.city = 'Virginia Beach'


    console.log('___________________________')
  }
  
  
}

export default Test;
